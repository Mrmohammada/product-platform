# Product Platform

## مراحل اجرا
1. متغیرهای محیطی API_KEY و BOT_TOKEN را تنظیم کنید
2. نصب:
   pip install -r requirements.txt
3. اجرای بک‌اند:
   uvicorn backend.main:app --reload
4. اجرای ربات:
   python bot/bot.py
